package com.mx.dcadena.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.mx.dcadena.dao.PesadaDAO;
import com.mx.dcadena.to.PesadaTO;

@Repository
public class PesadaDAOImpl extends GenericDAOImpl<PesadaTO, Long> implements
		PesadaDAO {

	public PesadaDAOImpl() {
		super(PesadaTO.class);
	}

	public void insert(PesadaTO pesadaTO) {
		guardar(pesadaTO);
	}

	public void update(PesadaTO pesadaTO) {
		actualizar(pesadaTO);
	}

	public void delete(PesadaTO pesadaTO) {
		borrar(pesadaTO);
	}

	public List<PesadaTO> getAll() {
		return buscar();
	}

	public List<PesadaTO> getPesadaByFecha(String fecha) {

		StringBuilder builder = new StringBuilder(
				"from PesadaTO where fecha = '").append(fecha).append("'");

		return this.executeQueryGetList(builder.toString());
	}

}
